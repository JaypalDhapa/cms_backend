// src/modules/course/course.repository.js
// CHANGED:
//   1. buildCourseFilter — added categoryId filter
//   2. findCourses — populates category field
//   3. findCourse — populates category field
//   4. updateCourse — populates category field
//   5. All reads populate category for frontend display

import Course from './course.model.js';
import Section from '../section/section.model.js';
import Lesson from '../lesson/lesson.model.js';
import {
  parsePaginationArgs,
  buildMongoosePaginationQuery,
  buildConnection,
} from '../../utils/pagination.js';

function buildCourseFilter(filters = {}) {
  const filter = { isDeleted: filters.isDeleted ?? false };
  if (filters.isPublished != null) filter.isPublished = filters.isPublished;
  // Filter by category — when categoryId provided, scope to that category
  if (filters.categoryId != null) filter.category = filters.categoryId;
  return filter;
}

// ── GET ONE ───────────────────────────────────────────────────────────────────

export async function findCourse({ id, slug }) {
  if (!id && !slug) throw new Error('Provide id or slug');
  return Course.findOne({
    ...(id ? { _id: id } : { slug }),
    isDeleted: false,
  })
    .populate('category', 'name _id')
    .lean();
}

// ── GET MANY (cursor-paginated) ───────────────────────────────────────────────

export async function findCourses(args = {}) {
  const { filters = {}, ...paginationRawArgs } = args;

  const pagination = parsePaginationArgs(paginationRawArgs);
  const baseFilter = buildCourseFilter(filters);
  const { sort, filter: cursorFilter } = buildMongoosePaginationQuery({
    cursor: pagination.cursor,
    sortField: 'order',
  });

  const finalFilter = {
    ...baseFilter,
    ...(Object.keys(cursorFilter).length ? cursorFilter : {}),
  };

  const [docs, totalCount] = await Promise.all([
    Course.find(finalFilter)
      .sort(sort)
      .limit(pagination.limit + 1)
      .populate('category', 'name _id')
      .lean(),
    Course.countDocuments(baseFilter),
  ]);

  return buildConnection({
    docs,
    limit: pagination.limit,
    totalCount,
    sortField: 'order',
  });
}

// ── CREATE ────────────────────────────────────────────────────────────────────

export async function createCourse(data) {
  const doc = await new Course(data).save();
  return Course.findById(doc._id).populate('category', 'name _id').lean();
}

// ── UPDATE ────────────────────────────────────────────────────────────────────

export async function updateCourse(id, data) {
  const updated = await Course.findOneAndUpdate(
    { _id: id, isDeleted: false },
    { $set: data },
    { new: true, runValidators: true }
  )
    .populate('category', 'name _id')
    .lean();
  return updated;
}

// ── SOFT DELETE ───────────────────────────────────────────────────────────────

export async function softDeleteCourse(id) {
  const result = await Course.findOneAndUpdate(
    { _id: id, isDeleted: false },
    { $set: { isDeleted: true } }
  );
  return !!result;
}

// ── RESTORE ───────────────────────────────────────────────────────────────────

export async function restoreCourse(id) {
  const restored = await Course.findOneAndUpdate(
    { _id: id, isDeleted: true },
    { $set: { isDeleted: false } },
    { new: true }
  )
    .populate('category', 'name _id')
    .lean();
  if (!restored) throw new Error('Course not found or not deleted');
  return restored;
}

// ── CHILD COUNTS (for delete safety and resolver fields) ──────────────────────

export async function countSectionsInCourse(courseId) {
  return Section.countDocuments({ course: courseId, isDeleted: false });
}

export async function countRootLessonsInCourse(courseId) {
  // Root level lessons = lessons with section: null under this course
  return Lesson.countDocuments({
    course: courseId,
    section: null,
    isDeleted: false,
  });
}
